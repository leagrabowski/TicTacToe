/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tictactoe;


import java.util.InputMismatchException;
import java.util.Scanner;
/**
 *
 * @author leagr
 */
public class Tictactoe {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //this program plays tictactoe
        char [][]board = new char [17][17]; //create 2D array to form the tictactoeboard
        createBoard(board); //Print board via method
        
        Scanner input = new Scanner(System.in);
        char player = 'X';
        int plays = 0;
        while(plays < 9){
            System.out.println("It is " + player + "'s turn");
            System.out.println("Enter an available number:");
            int pos;
            try{
                
             pos = input.nextInt();
             input.nextLine();
            }catch(InputMismatchException e){ //If not a number, then invalid
                System.out.println("You must enter a number.");
                continue;
            }
            
            int boardX = ((pos - 1) / 3) * 6 + 2; //Gets x position for entered number
            int boardY = ((pos - 1) % 3) * 6 + 2; //Gets y position for entered number
            if(board[boardX][boardY] == 'X' || board[boardX][boardY] == 'O' || pos < 1 || pos > 9){ //If that spot is taken or if the number is less than 1 or greater than 9, then invslid
                System.out.println("You must enter a valid position.");
                continue;
            }
            
            board[boardX][boardY] = player;
            if (player == 'X') { //Switch between X and O
                player = 'O';
            } else {
                player = 'X';
            }
            plays++;
            printBoard(board);
            winCondition(board, plays);
        }
        
        System.out.println();
        }
        
    
    public static void createBoard(char[][] board) {
        int row;
        int col;
        for (col = 0; col < 17; col++) {
            for (row = 0; row < 17; row ++) {
                board[row][col] = ' '; //fill board with empty space
            }
        }
        
        for (row = 0; row < 17; row++) //insert first row
            board[row][5] = '|';
        
        for (row = 0; row < 17; row++) //insert second row
            board[row][11] = '|';
        
        for (col = 0; col < 17; col++) //insert first column
            board[5][col] = '-';
        
        for (col = 0; col < 17; col++) //insert second column
            board[11][col] = '-';
        
        board[2][2] = '1'; //set 1 in middle of first block, set the rest of numbers  below
        board[8][2] = '4';
        board[14][2] = '7';
        board[2][8] = '2';
        board[8][8] = '5';
        board[14][8] = '8';
        board[2][14] = '3';
        board[8][14] = '6';
        board[14][14] = '9';
        
        printBoard(board);
        
        System.out.println();
    }
    
    public static void printBoard(char[][]board) {
        for (int i = 0; i < 17; i++) {
            System.out.println("");
            for (int k = 0; k < 17; k++) {
                System.out.print(board[i][k]);
            }
        }
        
        
    }
    
    public static void winCondition(char[][]board, int plays) {
        if (board[2][2] == 'X' && board[2][8] == 'X' && board[2][14] == 'X') { //first column down X
            System.out.println("X wins!");   
            System.exit(0);
        } else if (board[2][2] == 'O' && board[2][8] == 'O' && board[2][14] == 'O') { //first column down O
            System.out.println("O wins!");
            System.exit(0);
        } else if (board[2][2] == 'O' && board[8][2] == 'O' && board[14][2] == 'O') { //First row O
            System.out.println("O wins!");
            System.exit(0);
        } else if (board[2][2] == 'X' && board[8][2] == 'X' && board[14][2] == 'X') { //First row X
            System.out.println("X wins!");
            System.exit(0);
        } else if (board[2][2] == 'X' && board[8][8] == 'X' && board[14][14] == 'X') { //Diagonal \ X
            System.out.println("X wins!");
            System.exit(0);
        } else if (board[2][2] == 'O' && board[8][8] == 'O' && board[14][14] == 'O') {//Diagonal \ O
            System.out.println("O wins!");
            System.exit(0);
        } else if (board[2][8] == 'O' && board[8][8] == 'O' && board[14][8] == 'O') { //Second column O
            System.out.println("O wins!");
            System.exit(0);
        } else if (board[2][8] == 'X' && board[8][8] == 'X' && board[14][8] == 'X') { //Second column X
            System.out.println("X wins!");
            System.exit(0);
        } else if (board[2][14] == 'X' && board[8][14] == 'X' && board[14][14] == 'X') { //third column X
            System.out.println("X wins!");
            System.exit(0);
        } else if (board[2][14] == 'O' && board[8][14] == 'O' && board[14][14] == 'O') { //third column o
            System.out.println("O wins!");
            System.exit(0);
        } else if (board[2][14] == 'O' && board[8][8] == 'O' && board[14][2] == 'O') { //diagonal / O
            System.out.println("O wins!");
            System.exit(0);
        } else if (board[2][14] == 'X' && board[8][8] == 'X' && board[14][2] == 'X') { //diagonal / X
            System.out.println("X wins!");
            System.exit(0);
        } else if (board[8][2] == 'X' && board[8][8] == 'X' && board[8][14] == 'X') { //middle row X
            System.out.println("X wins!");
            System.exit(0);
        } else if (board[8][2] == 'O' && board[8][8] == 'O' && board[8][14] == 'O') { //middle row O
            System.out.println("O wins!");
            System.exit(0);
        } else if (board[14][2] == 'O' && board[14][8] == 'O' && board[14][14] == 'O') { //third row O
            System.out.println("O wins!");
            System.exit(0);
        } else if (board[14][2] == 'X' && board[14][8] == 'X' && board[14][14] == 'X') { //third row X
            System.out.println("X wins!");
            System.exit(0);
    } else if (plays == 9) {
            System.out.println("Tie!");
        }
    
    
    
}
}
